package com.samuelbernard147.moviecataloguelocalstorage.Model;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import com.samuelbernard147.moviecataloguelocalstorage.db.DatabaseContract;

import org.json.JSONArray;

import static com.samuelbernard147.moviecataloguelocalstorage.db.DatabaseContract.getColumnInt;
import static com.samuelbernard147.moviecataloguelocalstorage.db.DatabaseContract.getColumnString;

public class Movie implements Parcelable {
    private int id;
    private String title;
    private String poster;
    private String overview;
    private String type;
    private String releaseDate;

    public static final String TYPE_MOVIE = "movie";
    public static final String TYPE_TV = "tv";

    public Movie() {
    }

    public Movie(Cursor cursor) {
        this.id = getColumnInt(cursor, DatabaseContract.FavColumns.FAVID);
        this.title = getColumnString(cursor, DatabaseContract.FavColumns.TITLE);
        this.poster = getColumnString(cursor, DatabaseContract.FavColumns.POSTER);
        this.overview = getColumnString(cursor, DatabaseContract.FavColumns.OVERVIEW);
        this.type = getColumnString(cursor, DatabaseContract.FavColumns.TYPE);
    }

    /*
     * Method untuk setMovie melalui API themoviedb
     * parameter berupa JsonArray, posisi object
     * dan type untuk menentukan tipe yang akan di load (Movie/Tv)
     */
    public void setMovie(JSONArray listObject, int posisi, String type) {
        if (type.equals(TYPE_MOVIE)) {
            try {
                int id = listObject.getJSONObject(posisi).getInt("id");
                String title = listObject.getJSONObject(posisi).getString("title");
                String poster = listObject.getJSONObject(posisi).getString("poster_path");
                String overview = listObject.getJSONObject(posisi).getString("overview");
                String releaseDate = listObject.getJSONObject(posisi).getString("release_date");

                this.id = id;
                this.title = title;
                this.poster = poster;
                this.overview = overview;
                this.releaseDate = releaseDate;
                this.type = TYPE_MOVIE;

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            try {
                int id = listObject.getJSONObject(posisi).getInt("id");
                String title = listObject.getJSONObject(posisi).getString("original_name");
                String poster = listObject.getJSONObject(posisi).getString("poster_path");
                String overview = listObject.getJSONObject(posisi).getString("overview");
                String releaseDate = listObject.getJSONObject(posisi).getString("first_air_date");

                this.id = id;
                this.title = title;
                this.poster = poster;
                this.overview = overview;
                this.releaseDate = releaseDate;
                this.type = TYPE_TV;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //    Getter Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    //  Parcelable
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.title);
        dest.writeString(this.poster);
        dest.writeString(this.overview);
        dest.writeString(this.type);
        dest.writeString(this.releaseDate);
    }

    public Movie(Parcel in) {
        this.id = in.readInt();
        this.title = in.readString();
        this.poster = in.readString();
        this.overview = in.readString();
        this.type = in.readString();
        this.releaseDate = in.readString();
    }

    public static final Parcelable.Creator<Movie> CREATOR = new Parcelable.Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}