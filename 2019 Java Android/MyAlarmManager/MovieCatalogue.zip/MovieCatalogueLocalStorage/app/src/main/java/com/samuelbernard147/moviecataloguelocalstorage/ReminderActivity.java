package com.samuelbernard147.moviecataloguelocalstorage;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.samuelbernard147.moviecataloguelocalstorage.alarm.AlarmReceiver;
import com.samuelbernard147.moviecataloguelocalstorage.preference.SettingsPreference;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReminderActivity extends AppCompatActivity {
    Switch swDaily, swRelease;
    private SettingsPreference mSettingPreference;
    AlarmReceiver alarmReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);
        swDaily = findViewById(R.id.sw_daily);
        swRelease = findViewById(R.id.sw_release);

        alarmReceiver = new AlarmReceiver();

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Movie Catalogue");
        }

        mSettingPreference = new SettingsPreference(this);

        swDaily.setChecked(mSettingPreference.getDaily());
        swRelease.setChecked(mSettingPreference.getRelease());

        swDaily.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Context context = buttonView.getContext();
                mSettingPreference.setDaily(isChecked);

                if (isChecked) {
                    alarmReceiver.setRepeatingReminder(context, AlarmReceiver.TYPE_DAILY,
                            "07:00", context.getResources().getString(R.string.daily_message), AlarmReceiver.ID_DAILY);
                } else {
                    alarmReceiver.cancelReminder(context, AlarmReceiver.TYPE_DAILY);
                }
            }
        });

        swRelease.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Context context = buttonView.getContext();
                mSettingPreference.setRelease(isChecked);

                if (isChecked) {
                    alarmReceiver.setRepeatingReminder(context, AlarmReceiver.TYPE_RELEASE,
                            "08:00", "Isi film yang baru rilis", AlarmReceiver.ID_RELEASE);
                } else {
                    alarmReceiver.cancelReminder(context, AlarmReceiver.TYPE_RELEASE);
                }
            }
        });
    }

    //    Untuk back
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}