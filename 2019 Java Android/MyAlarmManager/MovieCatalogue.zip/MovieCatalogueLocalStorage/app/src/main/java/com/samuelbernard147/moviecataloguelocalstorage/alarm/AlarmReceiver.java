package com.samuelbernard147.moviecataloguelocalstorage.alarm;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.samuelbernard147.moviecataloguelocalstorage.BuildConfig;
import com.samuelbernard147.moviecataloguelocalstorage.MainActivity;
import com.samuelbernard147.moviecataloguelocalstorage.Model.Movie;
import com.samuelbernard147.moviecataloguelocalstorage.R;
import com.samuelbernard147.moviecataloguelocalstorage.preference.SettingsPreference;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;

import static android.app.Notification.DEFAULT_LIGHTS;
import static android.app.Notification.DEFAULT_SOUND;
import static android.app.Notification.DEFAULT_VIBRATE;
import static android.content.Intent.ACTION_BOOT_COMPLETED;

public class AlarmReceiver extends BroadcastReceiver {
    // Siapkan 2 id untuk 2 macam alarm, daily dan release
    public final static int ID_DAILY = 100;
    public final static int ID_RELEASE = 101;

    //    TYPE REMINDER
    public static final String TYPE_DAILY = "Daily Reminder";
    public static final String TYPE_RELEASE = "Release Reminder";

    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_TYPE = "type";

    Context context;
    Calendar calendar = Calendar.getInstance();

    public AlarmReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String type = intent.getStringExtra(EXTRA_TYPE);
        String message = intent.getStringExtra(EXTRA_MESSAGE);

        String title = type.equalsIgnoreCase(TYPE_DAILY) ? TYPE_DAILY : TYPE_RELEASE;
        int notifId = type.equalsIgnoreCase(TYPE_DAILY) ? ID_DAILY : ID_RELEASE;
        this.context = context;

        if (intent.getStringExtra(EXTRA_TYPE) != null && intent.getStringExtra(EXTRA_MESSAGE) != null) {
            if (type.equals(TYPE_DAILY)) {
                if (checkTime(7)) {
                    Log.d("Masuk ke", "DAILY");
                    showReminderNotification(context, title, message, notifId);
                }
            } else if (type.equals(TYPE_RELEASE)) {
                if (checkTime(8)) {
                    Log.d("Masuk ke", "RELEASE");
                    getReleaseMovieData();
                }
            }

        } else {
            SettingsPreference settingsPreference = new SettingsPreference(context);
            String intentAction = intent.getAction();

            if (intentAction != null && intentAction.equals(ACTION_BOOT_COMPLETED)) {
                if (settingsPreference.getDaily()) {
                    setRepeatingReminder(context, TYPE_DAILY,
                            "07:00",
                            "Daily reminder",
                            ID_DAILY);
                }

                if (settingsPreference.getRelease()) {
                    setRepeatingReminder(context, TYPE_RELEASE,
                            "08:00",
                            "Release reminder",
                            ID_RELEASE);
                }
            }
        }
    }

    //    Cek jam
    private boolean checkTime(int targetHour) {
        boolean timeMatch = false;
        if (calendar.get(Calendar.HOUR_OF_DAY) == targetHour) {
            timeMatch = true;
        }
        return timeMatch;
    }

    // Metode menampilkan toast
    private void showToast(Context context, String title, String message) {
        Toast.makeText(context, title + " : " + message, Toast.LENGTH_LONG).show();
    }

    // Memunculkan notifikasi
    private void showReminderNotification(Context context, String title, String message, int notifId) {
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationManager notificationManagerCompat = (NotificationManager) context
                .getSystemService(Context.NOTIFICATION_SERVICE);

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, String.valueOf(notifId))
                .setSmallIcon(R.drawable.ic_access_time_white_24dp)
                .setContentTitle(title)
                .setContentText(message)
                .setColor(ContextCompat.getColor(context, android.R.color.transparent))
                .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setDefaults(DEFAULT_SOUND | DEFAULT_VIBRATE | DEFAULT_LIGHTS)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setSound(alarmSound)
                .setContentIntent(pendingIntent);

//        Android oreo keatas
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            /* Create or update. */
            NotificationChannel channel = new NotificationChannel(String.valueOf(notifId),
                    title + " Channel",
                    NotificationManager.IMPORTANCE_DEFAULT);

            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{1000, 1000, 1000, 1000, 1000});

            builder.setChannelId(String.valueOf(notifId));

            if (notificationManagerCompat != null) {
                notificationManagerCompat.createNotificationChannel(channel);
            }
        }

        Notification notification = builder.build();

        if (notificationManagerCompat != null) {
            notificationManagerCompat.notify(notifId, notification);
        }
    }

    // Menjalankan reminder repeating
    public void setRepeatingReminder(Context context, String type, String time, String message, int requestCode) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra(EXTRA_MESSAGE, message);
        intent.putExtra(EXTRA_TYPE, type);

        String timeArray[] = time.split(":");

        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeArray[0]));
        calendar.set(Calendar.MINUTE, Integer.parseInt(timeArray[1]));
        calendar.set(Calendar.SECOND, 0);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, 0);
        if (alarmManager != null) {
            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY, pendingIntent);
        }
        showToast(context, type, "Reminder set up");
    }

    //    Membatalkan Reminder
    public void cancelReminder(Context context, String type) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        int requestCode = type.equalsIgnoreCase(TYPE_DAILY) ? ID_DAILY : ID_RELEASE;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, 0);
        pendingIntent.cancel();

        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }

        showToast(context, type, "Reminder dibatalkan");
    }

    //    Mengambil data movie baru
    public void getReleaseMovieData() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        final String currentDate = dateFormat.format(new Date());
        AsyncHttpClient client = new AsyncHttpClient();
        String url = "https://api.themoviedb.org/3/discover/movie?api_key=" + BuildConfig.TMDB_API_KEY + "&language=en-US";
        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    JSONArray responseArray = responseObject.getJSONArray("results");

                    for (int i = 0; i < responseArray.length(); i++) {
                        Movie movie = new Movie();
                        movie.setMovie(responseArray, i, Movie.TYPE_MOVIE);
//                        Bila tanggal sesuai notif akan ditampilkan
                        if (movie.getReleaseDate().equals(currentDate)) {
                            showReminderNotification(context, TYPE_RELEASE, movie.getTitle() + context.getResources().getString(R.string.release_message), ID_RELEASE);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Load New Release", "FAILED");
            }
        });
    }
}