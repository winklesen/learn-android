package com.samuelbernard147.moviecataloguelocalstorage.widget;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Binder;
import android.os.Bundle;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.samuelbernard147.moviecataloguelocalstorage.Model.Movie;
import com.samuelbernard147.moviecataloguelocalstorage.R;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import static com.samuelbernard147.moviecataloguelocalstorage.db.DatabaseContract.FavColumns.CONTENT_URI;

public class StackRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {
    private final Context mContext;
    private Cursor favList;

    StackRemoteViewsFactory(Context context) {
        mContext = context;
    }

    private Movie getItem(int position) {
        if (!favList.moveToPosition(position)) {
            throw new IllegalStateException("Position Invalid");
        }
        return new Movie(favList);
    }

    @Override
    public void onCreate() {
        favList = mContext.getContentResolver()
                .query(CONTENT_URI,
                        null,
                        null,
                        null,
                        null);
    }

    @Override
    public void onDataSetChanged() {
        if (favList != null) {
            favList.close();
        }

        final long identityToken = Binder.clearCallingIdentity();
        favList = mContext.getContentResolver()
                .query(CONTENT_URI,
                        null,
                        null,
                        null,
                        null);
        Binder.restoreCallingIdentity(identityToken);
    }

    @Override
    public void onDestroy() {
        if (favList != null) {
            favList.close();
        }
    }

    @Override
    public int getCount() {
        if (favList == null) {
            return 0;
        }
        return favList.getCount();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        RemoteViews remoteViews = new RemoteViews(mContext.getPackageName(), R.layout.widget_item);
        Movie movie = getItem(position);
        Bitmap bitmap = null;
        try {
            bitmap = Picasso.get().load("https://image.tmdb.org/t/p/w500" + movie.getPoster()).get();
        } catch (IOException e) {
            Log.e("Load Image", "Error");
        }
        remoteViews.setImageViewBitmap(R.id.imageView, bitmap);
        remoteViews.setTextViewText(R.id.widgetTitle, movie.getTitle());

        Bundle extras = new Bundle();
        extras.putInt(FavouriteWidget.EXTRA_ITEM, position);
        Intent fillInIntent = new Intent();
        fillInIntent.putExtras(extras);

        remoteViews.setOnClickFillInIntent(R.id.imageView, fillInIntent);
        return remoteViews;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }
}
