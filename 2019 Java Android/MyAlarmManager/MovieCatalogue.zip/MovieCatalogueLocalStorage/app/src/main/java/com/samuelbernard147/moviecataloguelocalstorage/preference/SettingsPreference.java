package com.samuelbernard147.moviecataloguelocalstorage.preference;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsPreference {
    private static final String PREFS_NAME = "settings_pref";

    private static final String LANG = "lang";
    private static final String RELEASE = "release";
    private static final String DAILY = "daily";

    private final SharedPreferences preferences;

    public SettingsPreference(Context context) {
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void setRelease(Boolean value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(RELEASE, value);
        editor.apply();
    }

    public void setDaily(Boolean value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(DAILY, value);
        editor.apply();
    }

    public void setLang(String value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(LANG, value);
        editor.apply();
    }

    //    Nilai default dari bahasanya adalah bahasa Indonesia
    public String getLang() {
        return preferences.getString(LANG, "in");
    }

    public boolean getRelease() {
        return preferences.getBoolean(RELEASE, false);
    }

    public boolean getDaily() {
        return preferences.getBoolean(DAILY, false);
    }
}